import re

class TextFileProcessor:
    def __init__(self, filename):
        self.filename = filename
        self.data = []
        self.filters = []
        self.print_commands = []
        self.add_commands = []
        self.replace_commands = []
        self.load_data()

    def load_data(self):
        with open(self.filename, 'r') as f:
            self.data = f.readlines()

    def apply_filters(self):
        filtered_data = self.data
        for string_filter in self.filters:
            if not string_filter.startswith("/") and not string_filter.endswith("/"):
                filtered_data = [line for line in filtered_data if string_filter in line]
            else:
                regex = string_filter[1:-1]
                filtered_data = [line for line in filtered_data if re.search(regex, line)]
        return filtered_data

    def go(self):
        processed_lines = self.apply_filters()

        results = []

        for print_command in self.print_commands:
            indices = [int(num[1:]) - 1 for num in print_command.split()]
            for line in processed_lines:
                words = line.split()
                result = [words[i] for i in indices if i < len(words)]
                results.append(" ".join(result))

        for add_command in self.add_commands:
            idx1, idx2 = map(lambda x: int(x[1:]) - 1, add_command.split())
            for i in range(len(processed_lines)):
                words = processed_lines[i].split()
                try:
                    if idx1 < len(words) and idx2 < len(words):
                        result = str(int(words[idx1]) + int(words[idx2]))
                        words[idx1] = result
                        processed_lines[i] = " ".join(words)
                except ValueError:
                    pass

        for replace_command in self.replace_commands:
            parts = replace_command.split()
            if len(parts) == 2:
                old_word, new_word = parts
                processed_lines = [line.replace(old_word, new_word) for line in processed_lines]
            elif len(parts) == 3:
                index = int(parts[0][1:]) - 1
                new_word = parts[1]
                for i in range(len(processed_lines)):
                    words = processed_lines[i].split()
                    if index < len(words):
                        words[index] = new_word
                        processed_lines[i] = " ".join(words)

        for result in results:
            print(result)
        
        for line in processed_lines:
            print(line)

    def process_command(self, command):
        parts = command.split()
        cmd_type = parts[0]

        if cmd_type == "filter":
            self.filters.append(" ".join(parts[1:]))
        elif cmd_type == "print":
            self.print_commands.append(" ".join(parts[1:]))
        elif cmd_type == "add":
            self.add_commands.append(" ".join(parts[1:]))
        elif cmd_type == "replace":
            self.replace_commands.append(" ".join(parts[1:]))
        elif cmd_type == "go":
            self.go()
        else:
            print(f"Unknown command: {cmd_type}")

def main():
    processor = TextFileProcessor('file.txt')
    while True:
        command = input("Введите команду (или 'exit' для выхода): ")
        if command.lower() == 'exit':
            break
        processor.process_command(command)

if __name__ == "__main__":
    main()
